=============================
Turbo Engine 16 v0.31b Readme
=============================

by AamirM, Copyright (C) 2009


Legal Stuff
===========

Turbo Engine 16 is Copyright (C) 2009, AamirM. All rights reserved.

You may use and/or redistribute Turbo Engine 16 provided that you :

1) Do not modify and/or alter, in any way, the files included.
2) You distribute all the files you got originally with Turbo Engine 16.
3) You may not sell, lease, rent or otherwise seek to gain monetary profit
   from Turbo Engine 16.
4) You may not distribute Turbo Engine 16 with ROM images unless you have the legal
   right to distribute them.
5) You may not use Turbo Engine 16 for commercial purposes.

DISCLAIMER: The author of Turbo Engine 16 doesn't guarantee its fitness for any purpose,
implied or otherwise, and do not except responsibility for any damages
whatsoever that might occur when using Turbo Engine 16. All games emulated by Turbo Engine 16,
including any images and sounds therein, are copyrighted by their respective
copyright holders. Turbo Engine 16 DOES NOT INCLUDE any ROM images of emulated games.

Turbo Engine 16 is not authorized by, endorsed by, or affiliated with 
NEC and Hudson Soft in any way.


Introduction
============

Turbo Engine 16 is a NEC PC-Engine/TurboGrafx-16, SuperGrafx, CDROM�, Super CDROM�
emulator aiming for maximum accuracy.

In addition, it contains other nice features as well. ;)

For CD ROM images, Turbo Engine only supports CUE/BIN/ISO + OGG/MPC. OGG/MPC support
is there because most, if not all, of the rips I found were in either one of those two.
In future, audio plugins will be supported which will allow other formats to be added
as well.

If someone wants to help me in creating a better readme/documentation files, I'll
appreciate it very much. Just contact me.


Requirements
============

These are the minimum requirements to get most games running comfortably.
If you are emulating Supergrafx, these can rise significantly.

Processor:	At least a Pentium 4 2.2+ Ghz
Memory	 :	128 MB
Video	 :	DirectX 7 or above compatible card
Sound	 :	DirectSound compatible sound card
Input	 :	Keyboard, gamepads/joypads are supported


Default Keys
============

Run	--	Enter
I	--	A
II	--	S
Select	--	D
Up, Down, Left, Right	-- Direction keys


Video Plugins
=============

Turbo Engine supports Kega Fusion plugin system. So all plugins
supported by Kega are supported by Turbo Engine. A few also come
by default with this distribution. Plugins should be placed in
the "Plugin" subfolder where Turbo Engine is installed. Here is
what each one does:

Normal 2x	---	Simple pixel doubler
Interpolated 2x	---	Scale using bilinear interpolation


Cheats
======

The format of the Turbo Engine cheat file is like this:

[Cheat Number]
Name=Cheat Name
0=Option 1,address:data
1=Option 2,address:data,address:data
2=Option 3,address:data
3=Option 4,address:data,address:data,address:data
.....

Cheat Number starts from 0. An example is as follows:

[0]
Name=Infinite Lives
0=Off
1=On,10F123:0001

[1]
Name=Weapons
0=off,
1=Bombs,10F123:0001
2=Grenade,10F123:0002
3=Laser gun,10F123:0003
3=Shotgun,10F123:0004

If someone wants, I can make a cheat converter to convert cheats
from format used by other emulators to Turbo Engine cheats.
Just mail me or post a request at the forums (links given later) if
you want it. A converter for MESS/MAME XML to Turbo Engine cheat is
available from my homepage.


Acknowledgements
================

Honourable mention goes to the following people who have helped me
quite a bit in some way in making this emulator:

Charles MacDonald, Mednafen author, Exophase, Shay Green (blargg, for FIR resampler and Blip_Buffer),
Paul Cliford, Tomaitheous, David Shadoff, Ki, Aladar, Mark Lord, Bernie Lindell, Raziel.

For more copyrights notices of the libraries used, see bottom of this doc.


Contact
=======

Bugs, feature request, and anything emulation related is welcomed.
ROM requests will be ignored.

I don't want to buy Viagra for $5 and I am not going to help you transfer your
$10 million from Nigeria to here even though you'll share it with me if I do,
so stop spamming me.

If you want to report a bug, have a feature request, do constructive critisicm
or are having any problems, then please post them at:

http://board.zsnes.com/phpBB2/viewtopic.php?t=11857

You can also contact me at "aamir dot m at live dot com"

where dot = .
      at = @

Thanks for trying my emulator and stay safe,

AamirM


History
=======

Version 0.32
------------

* Fixed sound cracking/buzzing in CD-ROM games.

* Improved BXR/BYR latch timings (hopefully). Fixes sprite corruption in Deep Blue (J).

* Then found out that the above change breaks other games so reverted it back :D.

* Fixed a memory handler related bug which caused some games to crash Turbo Engine.

* Fixed the problem of scanlines looking ugly when Window size multiplier of 3
  is selected.
  
* Slightly improved sound mixing speed.

* Fixed a small localization DLL setting bug.


Version 0.31b
-------------
Another small update:

* Added the option to rip audio tracks to OGG format in cd ripping tool.

* Fixed a major bug in save state code.

* Added "Power Saving Mode" for laptops, notebooks and netbooks etc..
  When this is enabled, Turbo Engine will not use 100% CPU, to save
  battery. But you may get occasional stuttering, skips under this.
  For me, under this option, Turbo Engine uses 0%-5% CPU which should
  save quite a bit of battery ;) .
  
* Fixed a small bug in localization DLL versioning code. Now Turbo Engine
  won't crash if a language file isn't found.


Version 0.31a
-------------
Quick and small update:

* Fixed a problem that prevented Turbo Engine from running on some AMD
  CPUs.

* Fixed a linking problem in compiler which caused Turbo Engine to fail
  to load on some computers.
  
* Fixed part of "About" dialog box text getting cut-off.

* Reverted back a change I made in Tremor (OGG decoder) which caused
  OGG playback to completely fail in release builds.
  

Version 0.31
------------
This is a small update. Only some front-end feature have been fixed/added.
No emulation related changes have been made.

* On Win2k/XP/Vista, IOCTL is used to handle CDROM now. This means you don't
  need ASPI manager (wnaspi32.dll) anymore on those operating systems.
  You can however still enable ASPI if you want by modifying "TurboEngine.ini"
  and setting "ForceASPI=1". On 9x/ME systems, it'll use ASPI automatically.

* Cheats fixed (again). A cheat converter is also available on my homepage
  which can convert cheats from MESS/MAME's XML to Turbo Engine's cheat DATs.

* Complete localization/translation support (including dialog boxes). 
  See the "Localization.txt" in "Languages" folder for information on translating.
  If you do a translation, please please and PLEASE do submit them to me. ;)
  
* Turbo Engine now warns for unconfigured BIOS while loading CDROM games.

* CD ripping works in another thread so that the GUI is updated and emulator doesn't
  get freezed until ripping is finished.

* Added command line support. The syntax is:
  
  "TurboEngine [--fullscreen] path_to_rom.[bin,pce,zip,7z,cue,iso]"
  
* Fixed some crashes. Improved stability a bit (hopefully).

* Increased speed. Now it should be a little faster (but don't expect too fast).
  A lot more is still to be done in this area :) .
  

Version 0.3 aka "TF109"
-----------------------
I had planned a few more things for this release but I couldn't get the time
to finish them off. Especially the audio plugins, but I guess thats for the next
release now ;). Also, if I forgot any feature you had asked, I apologize for it.

* Added CD-ROM emulation!!
* Added physical CD handling using ASPI.
* Added CUE/BIN/ISO+OGG/MPC support.
* Savestate support for CD-ROM games.
* Fixed a timer issue which fixes Double Dungeons and Champions Forever Boxing.
* Fixed B&W mode not working when brighten disabled.
* TE shows a real "Turbo Engine" on startup ;) .
* Fixed a bug in fullscreen code which caused TE to crash while exiting from fullscreen.
* Added a "FastVDC" option to the ini file.
* Cheats fixed.
* Added Arcade Card support.
* Option to enable/disable arcade card.
* Dialog box to configure various paths easily. (Under "Misc->Configure Paths")
* Added filtered/unfiltered screenshot support.
* Added PNG and BMP screenshot support.
* Added WAVE file sound logging.
* Added HES Music file loading with nice oscilloscope display :) .
* Added Input movie recording and replaying feature.
* Added rewinding feature (*highly* experimental).
* Added frame advance feature (only useful while emu is paused).
* Added slow mode feature.
* Improved video plugin support. All plugins are supported now (that is, upto 4x scalers).
* Added ability to enable/disable PSG channels, CD Audio and ADPCM.
* Added 7-zip support.
* Added many pre-defined scanline settings.
* Added custom scanline intensity option.
* Added bitmapped text support.
* FPS are now displayed in lower right corner instead of the titlebar.
* Added suport to rip (PCE) CDROMs into CUE/ISO+Wave. 
  After that you can convert audio to whatever format you prefer (OGG or MPC).
* Added 6 button pad support.
* Added Multitap support. Now you can use upto five controllers.
* Quite a lot more stuff but I can't remember all of it now. >_>


Version 0.20 aka "the serious version" :)
-----------------------------------------
This release is a complete rewrite of the emulator. It will be quite
a lot slower compared to the previous releases.

* CPU emulator rewritten.
* Completely new PSG with more accurate noise emulation.
* Completely new VDC/VCE core. More accurate. Everything is implemented now.
* Cycle accurate sample generation support.
* New "High Quality" sound mode. Will result in more accurate sound. This can
  slow down the emulation speed quite considerably so only turn it on if 
  you have a fast enough PC.
* SuperGrafx support. All SGX games run perfectly.
* Street Fighter 2 banking support.
* Almost all glitches should now be gone.
* Configuration file containg emulator related settings is now created.
  Some setting, righ now, can only be changed by modifiying it.
* Save state support. By default, the quick save states will be saved
  in the "Saves" subfolder. It can be changed by changing "StatePath" 
  in TurboEngine.ini.
* Turbo Engine now remembers recently loaded ROMs. "File History" will
  contain recently loaded ROMs along with its full path.
* Setting "ShortHistoryNames" in TurboEngine.ini to 1 will only display ROM
  names instead of its full path in "File History".
* Support for changing Window sizes.
* Fullscreen support. It is a bit buggy at the moment. But will work out
  most of the time.
* VSync support. This will remove tearing in the video. Depending on your
  monitor or video card, it can also cause stuttering in video or sound.
* Kega Fusion plugin system support. Only 2x scalers supported at the moment.
* Turbo Mode support.
* Brighten option added. This will take out the differences between the TV
  and monitor brightness. It is recommended to turn it on.
* Various overscan options added.
* Many aspect ratio correction options added. Note that "Correct aspect ratio"
  will only work in fullscreen mode. For correcting aspect in windowed mode,
  use "Window Ratio" option.
* Window aspect ratio correction option added.
* Option to disable sound.
* Lowpass filter option added.
* Loud option added to make PSG a bit more heavy and effective :) . Though
  it can result in sound getting clipped.
* Option to Save/Load BRAM. If turned on, BRAM will be saved or loaded
  otherwise it will be discarded.
* Cheat file support added.
* DirectInput support added. This means joypads, gamepads, joysticks etc..
  are now supported.
* Option to redefine input settings. Note that 6-button option, though
  listed, will not work.
* Option to revert key settings back to default.
* Option to make window top most.
* Autopasue option added which will pause the emulator whenever it loses focus.
* High priority option added.
* Option to disable screen savers while emulator is running.
* Option to show FPS.
* About box added ;) .


Version 0.15
------------
* Various fixes to the CPU core and some timing changes. Thanks to Exophase
  for posting comments on the emutalk boards. Fixes the following games:
	- Cyber Core
	- Download
	- Final Soldier
	- Blodia
	- Body Conquest II
	- Idol Hanafuda Fan Club
	- Jackie Chan
	- Jackie Chan Action Kung Fu
	- Kyuukyoku Mahjong Idol Graphic
	- Kyuukyoku Mahjong Idol Graphic II
	- New Adventure Island
* Fixed a silly bug in CPU timer. I probably shouldn't code at night.
* Fixed sound in Bouken Danshaku Don.
* Fixed CPU low speed mode.
* Inter-sprite priorities implemented (Bomberman, Racing Damashii, and just about every game).
* Sprites to background priority corrected (Cadash).
* Sprite limitations implemented (After Burner II).
* Support for bit shuffled USA ROMs (Cadash, Final Lap Twin etc..).
* Turbo Engine will now use sound card for timing. This wil remove video stuttering,
  sound skipping and hiccups in the emulation.
* Change of name from Turbo Engine to Turbo Engine 16 to avoid confusion with
  car engines when some one googles it :)


Version 0.1
-----------
* First public release
* H6280(CPU) 	 : 100% complete. Needs testing. Maybe some bugs in there.
* VDC/VCE(video) : 75% complete. Very basic things added. Timings are very
		   incorrect right now. Renderer is missing a few things.
* PSG(sound)	 : 95% complete. No LFO support (there are 4 games that use
		   this as far as I know). Noise emulation is not 100% too.
* CD-ROM	 : 0%
* Supergrafx	 : 55%
* Controllers	 : 50%. No 6-button controller support.
* About 97% games manage to boot. This doesn't mean they're playable though.
* Very basic GUI.
* DirectDraw graphics output added.
* DirectSound support added.
* Zip ROM support


Copyright Notices:
==================

Turbo Engine also uses a few nice libraries which require that I put their
copyright notices in the docs. So here they are:

Tremor:
=======
Copyright (c) 2002, Xiph.org Foundation

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

- Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

- Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

- Neither the name of the Xiph.org Foundation nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

libmpcdec:
==========
  Copyright (c) 2005, The Musepack Development Team
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are
  met:

  * Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the following
  disclaimer in the documentation and/or other materials provided
  with the distribution.

  * Neither the name of the The Musepack Development Team nor the
  names of its contributors may be used to endorse or promote
  products derived from this software without specific prior
  written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

zlib
====
http://www.zlib.net/

Copyright (C) 1995-2004 Jean-loup Gailly and Mark Adler

unzip
=====
http://www.winimage.com/zLibDll/unzip.html

Copyright (C) 1998-2004 Gilles Vollant

libpng
======
http://www.libpng.org/pub/png/libpng.html

Copyright (c) 1998-2002 Glenn Randers-Pehrson
Copyright (c) 1996-1997 Andreas Dilger
Copyright (c) 1995-1996 Guy Eric Schalnat, Group 42, Inc.

7-Zip
=====
LZMA SDK 4.21 Copyright (c) 1999-2005 Igor Pavlov (2005-06-08)
http://www.7-zip.org/
